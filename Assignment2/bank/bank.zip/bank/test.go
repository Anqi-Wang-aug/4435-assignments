package main

import(
	"fmt"
)

func main(){

	s := fmt.Sprintf("%f", 12%)
	fmt.Println(s)
}
